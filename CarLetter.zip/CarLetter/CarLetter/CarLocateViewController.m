//
//  CarLocateViewController.m
//  CarLetter
//
//  Created by 肖伟华 on 2017/2/22.
//  Copyright © 2017年 1019459067. All rights reserved.
//

#import "CarLocateViewController.h"

@interface CarLocateViewController ()

@end

@implementation CarLocateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor orangeColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
