//
//  MileageReportViewController.m
//  CarLetter
//
//  Created by 肖伟华 on 2017/2/22.
//  Copyright © 2017年 1019459067. All rights reserved.
//

#import "MileageReportViewController.h"

@interface MileageReportViewController ()

@end

@implementation MileageReportViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
