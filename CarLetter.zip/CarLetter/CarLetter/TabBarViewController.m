//
//  TabBarViewController.m
//  CarLetter
//
//  Created by 肖伟华 on 2017/2/22.
//  Copyright © 2017年 1019459067. All rights reserved.
//

#import "TabBarViewController.h"
#import "NavigationController.h"
#import "CarLocateViewController.h"
#import "AlarmRemindViewController.h"
#import "MileageReportViewController.h"

@interface TabBarViewController ()

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImage *image = [UIImage imageNamed:@"mmfooter_bg.9"];
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    
    UITabBarItem *item = [UITabBarItem appearance];
    NSMutableDictionary *normalAttr = [NSMutableDictionary dictionary];
    normalAttr[NSFontAttributeName] = [UIFont systemFontOfSize:14];
    normalAttr[NSForegroundColorAttributeName] = [UIColor grayColor];
    [item setTitleTextAttributes:normalAttr forState:UIControlStateNormal];
    NSMutableDictionary *selectedAttr = [NSMutableDictionary dictionary];
    selectedAttr[NSForegroundColorAttributeName] = [UIColor darkGrayColor];
    [item setTitleTextAttributes:selectedAttr forState:UIControlStateSelected];
    
    [self setupChildOneVC:
     [[NavigationController alloc]initWithRootViewController:[[CarLocateViewController alloc]init]]
                    title:@"车辆定位" image:@"dingwei" selectedImage:@"dingweiing"];
    
    [self setupChildOneVC:
     [[NavigationController alloc]initWithRootViewController:[[AlarmRemindViewController alloc]init]]
                    title:@"报警提醒" image:@"btm_warn" selectedImage:@"btm_warning"];
    
    [self setupChildOneVC:
     [[NavigationController alloc]initWithRootViewController:[[MileageReportViewController alloc]init]]
                    title:@"里程报表" image:@"baobiao" selectedImage:@"baobiaoing"];
    
}
- (void)setupChildOneVC:(UIViewController *)vc title:(NSString *)title image:(NSString *)strImg selectedImage:(NSString *)selectedImg
{
    vc.tabBarItem.title = title;
    if (strImg.length) {
        vc.tabBarItem.image = [UIImage imageNamed:strImg];
        vc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImg]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    }
    [self addChildViewController:vc];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
