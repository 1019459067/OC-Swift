//
//  SKViewController.h
//  SpriteKit
//

//  Copyright (c) 2014年 CpSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface SKViewController : UIViewController

@end
